require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const Course = require('./models/Course');
const Log = require('./models/Log');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.static('public'));

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI)
    .then(() => console.log('Connected to MongoDB'))
    .catch(err => {
        console.error('MongoDB connection error:', err);
        process.exit(1);
    });

// Routes
app.get('/courses', async (req, res) => {
    try {
        const courses = await Course.find().sort({ display: 1 });
        res.json(courses);
    } catch (error) {
        console.error('Error retrieving courses:', error);
        res.status(500).json({ error: 'Failed to retrieve courses' });
    }
});

app.post('/courses', async (req, res) => {
    try {
        const newCourse = req.body;
        
        // Validate required fields
        if (!newCourse.display || !newCourse.id) {
            return res.status(400).json({ 
                error: 'Missing required fields. Course ID and display name are required.' 
            });
        }

        // Check for duplicate course ID
        const existingCourse = await Course.findOne({ id: newCourse.id });
        if (existingCourse) {
            return res.status(409).json({ 
                error: 'Course with this ID already exists.' 
            });
        }

        const course = new Course(newCourse);
        await course.save();
        
        console.log(`New course added: ${newCourse.display}`);
        res.status(201).json(course);
    } catch (error) {
        console.error('Error adding new course:', error);
        if (error.name === 'ValidationError') {
            return res.status(400).json({ error: error.message });
        }
        res.status(500).json({ error: 'Failed to add course' });
    }
});

app.get('/logs', async (req, res) => {
    const { courseId, uvuId } = req.query;
    
    if (!uvuId) {
        return res.status(400).json({ error: 'UVU ID is required' });
    }

    try {
        const query = { uvuId };
        if (courseId) {
            query.courseId = courseId;
        }
        
        const logs = await Log.find(query).sort({ date: -1 });
        res.json(logs);
    } catch (error) {
        console.error('Error retrieving logs:', error);
        res.status(500).json({ error: 'Failed to retrieve logs' });
    }
});

app.post('/logs', async (req, res) => {
    const newLog = req.body;
    
    // Validate required fields
    if (!newLog.uvuId || !newLog.courseId || !newLog.text) {
        return res.status(400).json({ 
            error: 'Missing required fields. UVU ID, course ID, and text are required.' 
        });
    }

    try {
        const log = new Log(newLog);
        await log.save();
        
        console.log(`New log added for UVU ID: ${newLog.uvuId}`);
        res.json(log);
    } catch (error) {
        console.error('Error saving new log:', error);
        if (error.name === 'ValidationError') {
            return res.status(400).json({ error: error.message });
        }
        res.status(500).json({ error: 'Failed to save log' });
    }
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).sendFile(path.join(__dirname, 'public', 'error.html'));
});

// 404 handler
app.use((req, res) => {
    res.status(404).sendFile(path.join(__dirname, 'public', 'error.html'));
});

// Start server
if (require.main === module) {
    app.listen(PORT, () => {
        console.log(`Server running at http://localhost:${PORT}`);
    });
}

module.exports = app; 