'use strict';

$(document).ready(function () {
  const BASE_URL = "http://localhost:3000"; 

  /** Load Courses into Dropdown **/
  function loadCourses() {
    $.ajax({
      url: `${BASE_URL}/courses`,
      method: "GET",
      dataType: "json",
      success: function (courses) {
        $("#course").empty().append('<option selected value="">Choose Course</option>');
        $.each(courses, function (_, course) {
          $("#course").append(`<option value="${course.id}">${course.display}</option>`);
        });
      },
      error: function (xhr) {
        console.error("Failed to fetch courses:", xhr.responseJSON?.error || xhr.statusText);
        showError("Failed to load courses. Please try again.");
      }
    });
  }

  /** Add New Course **/
  function addNewCourse(courseData) {
    $.ajax({
      url: `${BASE_URL}/courses`,
      method: "POST",
      contentType: "application/json",
      data: JSON.stringify(courseData),
      success: function (newCourse) {
        // Add new course to dropdown
        $("#course").append(`<option value="${newCourse.id}">${newCourse.display}</option>`);
        
        // Show success message
        showSuccess("Course added successfully!");
        
        // Select the new course
        $("#course").val(newCourse.id).trigger('change');
      },
      error: function (xhr) {
        console.error("Failed to add course:", xhr.responseJSON?.error || xhr.statusText);
        showError(xhr.responseJSON?.error || "Failed to add course. Please try again.");
      }
    });
  }

  /** Show Success Message **/
  function showSuccess(message) {
    const successMsg = $('<div class="alert alert-success alert-dismissible fade show" role="alert">')
      .text(message)
      .append($('<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>'));
    
    $(".container").prepend(successMsg);
    setTimeout(() => successMsg.alert('close'), 3000);
  }

  /** Show Error Message **/
  function showError(message) {
    const errorMsg = $('<div class="alert alert-danger alert-dismissible fade show" role="alert">')
      .text(message)
      .append($('<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>'));
    
    $(".container").prepend(errorMsg);
    setTimeout(() => errorMsg.alert('close'), 5000);
  }

  /** Load Logs for Selected Course & UVU ID **/
  function loadLogs(courseId, uvuId) {
    $.ajax({
      url: `${BASE_URL}/logs`,
      method: "GET",
      data: { courseId, uvuId },
      dataType: "json",
      success: function (logs) {
        $("#uvuIdDisplay").text(`Student Logs for ${uvuId}`);
        const logList = $("ul[data-cy='logs']").empty();
        $.each(logs, function (_, log) {
          logList.append(`
            <li class="list-group-item">
              <div><small>${new Date(log.date).toLocaleString()}</small></div>
              <pre class="d-none"><p>${log.text}</p></pre>
            </li>
          `);
        });
      },
      error: function () {
        $("ul[data-cy='logs']").html('<li class="text-danger">Error fetching logs.</li>');
      }
    });
  }

  /** Course Selection Event **/
  $("#course").on("change", function () {
    const courseSelected = $(this).val() !== "";
    $("#uvuId").prop("disabled", !courseSelected);
  });

  /** UVU ID Input Event **/
  $("#uvuId").on("input", function () {
    let inputVal = $(this).val().replace(/\D/g, "").slice(0, 8);
    $(this).val(inputVal);

    if (inputVal.length === 8) {
      loadLogs($("#course").val(), inputVal);
    } else {
      $("ul[data-cy='logs']").empty();
    }
  });

  /** Log Entry Click (Toggle Visibility) **/
  $("ul[data-cy='logs']").on("click", "li", function () {
    $(this).find("pre").toggleClass("d-none");
  });

  /** Enable/Disable Add Log Button **/
  $("textarea[data-cy='log_textarea']").on("input", function () {
    $("#add_log_btn").prop("disabled", $(this).val().trim() === "");
  });

  /** Submit New Log **/
  $("#add_log_btn").on("click", function (event) {
    event.preventDefault();
    if ($(this).prop("disabled")) return;

    const newLog = {
      courseId: $("#course").val(),
      uvuId: $("#uvuId").val(),
      text: $("textarea[data-cy='log_textarea']").val().trim()
    };

    // Disable the button while submitting
    $("#add_log_btn").prop("disabled", true);

    $.ajax({
      url: `${BASE_URL}/logs`,
      method: "POST",
      contentType: "application/json",
      data: JSON.stringify(newLog),
      success: function (response) {
        // Clear the textarea
        $("textarea[data-cy='log_textarea']").val("");
        
        // Show success message
        showSuccess("Log added successfully!");
        
        // Reload logs to show the new entry
        loadLogs(newLog.courseId, newLog.uvuId);
      },
      error: function (xhr) {
        showError(xhr.responseJSON?.error || "Error adding log. Please try again.");
        console.error("Error adding log:", xhr.responseJSON?.error || xhr.statusText);
      },
      complete: function() {
        // Re-enable the button
        $("#add_log_btn").prop("disabled", false);
      }
    });
  });

  /** Bootstrap Dark Mode (No Custom CSS) **/
  const themeToggle = $("#themeSwitch");
  themeToggle.on("change", function () {
    $("body").toggleClass("bg-dark text-light", $(this).prop("checked"));
    $(".form-control, .list-group-item").toggleClass("bg-dark text-light border-secondary", $(this).prop("checked"));
    localStorage.setItem("theme", $(this).prop("checked") ? "dark" : "light");
  });

  if (localStorage.getItem("theme") === "dark") {
    themeToggle.prop("checked", true).trigger("change");
  }

  /** Handle New Course Form Submission **/
  $("#newCourseForm").on("submit", function(event) {
    event.preventDefault();
    
    const courseData = {
      id: $("#courseId").val().trim(),
      display: $("#courseDisplay").val().trim()
    };

    // Validate UUID format
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    if (!uuidRegex.test(courseData.id)) {
      showError("Invalid course ID format. Must be a valid UUID.");
      return;
    }

    // Add new course
    addNewCourse(courseData);

    // Clear form
    this.reset();
  });

  loadCourses(); // Load courses on page load
});
